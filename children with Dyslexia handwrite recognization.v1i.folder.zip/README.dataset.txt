# children with Dyslexia handwrite recognization > 2023-03-08 6:18pm
https://universe.roboflow.com/classification/children-with-dyslexia-handwrite-recognization

Provided by a Roboflow user
License: CC BY 4.0

